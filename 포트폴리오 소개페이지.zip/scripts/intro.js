$(function(){

    $('.pf02').hide();

    // 포트폴리오 메뉴
    $('.pf-menu li:eq(0)').click(function(){
        $(this).addClass('active')
            .next().removeClass('active');
        
        $('body').addClass('bg-on');
        $('.pf01').show();
        $('.pf02').hide();
    })

    

    // .pf01 - 웹사이트 리디자인(01)
    const swiper = new Swiper('.pf01 .swiper-container', {
        loop: false,
        slidesPerView:4,
        spaceBetween:0,
        pagination: {
            el: '.swiper-pagination',
            type: 'progressbar',
            
        },
    });



    // .pf02 - 웹콘텐츠 디자인(02)
    $('.pf-menu li:eq(1)').click(function(){
        $(this).addClass('active')
            .prev().removeClass('active');

        $('body').removeClass('bg-on');
        $('.pf01').hide();
        $('.pf02').show();

        const contItems = $('.pf02 > ul > li');
        contItems.each(function(index) {
            const delay = Math.random() * 400 + 100;
            $(this).delay(delay).queue(function(next) {
                $(this).addClass('show');
                next();
            });
        });

        // pf02 - 카드뉴스
        let newsWidth = $('.pf02 .news ul').width();
        console.log(newsWidth);
        $('.pf02 .news li').height(newsWidth);

    })


})